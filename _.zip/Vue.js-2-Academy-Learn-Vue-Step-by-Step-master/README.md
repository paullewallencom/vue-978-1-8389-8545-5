## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/vue-js-2-academy-learn-vue-step-by-step-video/9781838985455)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Vue.js-2-Academy-Learn-Vue-Step-by-Step
Vue.js 2 Academy: Learn Vue Step by Step, published by Packt
